import styled from "styled-components";

export const CheckBox = styled.div``;
