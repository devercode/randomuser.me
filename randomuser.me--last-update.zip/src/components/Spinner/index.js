export { default } from "./Spinner";
