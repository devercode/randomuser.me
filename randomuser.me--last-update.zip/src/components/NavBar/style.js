import styled from "styled-components";

export const tabPanel = styled.div`
  width: 70%;
  margin: 0 auto;
  padding-top: 100px;
`;
export const appBar = styled.div`
  position: fixed;
  top: 0;
`;
